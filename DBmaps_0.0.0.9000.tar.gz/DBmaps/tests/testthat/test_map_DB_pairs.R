library(testthat)
library(DBmaps)

test_that("map.DB.pairs returns a data.table with correct columns", {
  tables <- list(table1 = data.table(id = 1:3), table2 = data.table(id = 1:3))
  result <- map.DB.pairs(tables)
  expect_s3_class(result, "data.table")
  expect_equal(names(result), c("table_x", "table_y", "can_join", "by_x", "by_y"))
})